//
// RelationCloud Dynamics
//
// This code moves nodes around a central cloud using BubbleMesh ideas
// originally published as a mesh generation technique by Kenji
// Shimada.
//
// Nathan Collier, Dec 2009
//

// Cloud Functions --------------------------------------------------

// Initializes an allocated cloud pointer
extern void CreateCloud(Cloud *C) ;
// Deletes a Cloud and all its Nodes
extern void DeleteCloud(Cloud *C) ;
// Add an allocated Node to the cloud. The strength is how much it
// will resist the center node. The radius is how much it will resist
// other nodes.
extern void AddNode(Cloud *C,Node *N,double str,double radius) ;
// Deletes the specified nodes from the cloud
extern void DeleteNode(Cloud *C,Node *N) ;
// Shows the number of nodes in a cloud excluding the head
extern int Size(Cloud *C) ;
// Gets the i^th node of the cloud, 0 based, exlcudes the head
extern Node* Find(Cloud *C,int i) ;
// Finds a node of the cloud that is within the square centered at
// (x,y) which is 2(del) x 2(del)
extern Node* Find(Cloud *C,double x, double y, double del) ;
// (DEBUG) Writes out the centers to a specified stream
extern void PlotCloud(Cloud *C,ostream &os) ;

// Movement Functions ------------------------------------------------

// Moves all the nodes for dt
extern void MoveNodes(Cloud *C,double dt) ;
// Moves a particular node N by dt
extern void MoveNode(Cloud *C,Node *N,double dt) ;
// Calculates the node to node force components
extern void NodetoNodeForcing(Node *N1,Node *N2,double &fx, double &fy) ;
// Calculates the node to center forces
extern void CentralForcing(Cloud *C,Node *N,double &fx, double &fy) ;
