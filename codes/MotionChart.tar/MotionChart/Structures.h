//
// RelationCloud Dynamics
//
// This code moves nodes around a central cloud using BubbleMesh ideas
// originally published as a mesh generation technique by Kenji
// Shimada.
//
// Nathan Collier, Dec 2009
//

#ifndef _STRUCT_
#define _STRUCT_

typedef struct _Node
{
  double cx, cy, radius, str ;
  double cdx, cdy, c, m ;
  int imove ;
  char *label ;
  struct _Node *next ;
} Node ;

typedef struct _Cloud
{
  Node *head ;
  char *label ;
  int count ;
} Cloud ;

#endif
