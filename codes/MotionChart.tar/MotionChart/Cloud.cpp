//
// RelationCloud Dynamics
//
// This code moves nodes around a central cloud using BubbleMesh ideas
// originally published as a mesh generation technique by Kenji
// Shimada.
//
// Nathan Collier, Dec 2009
//

#include <iostream>
#include <fstream>
using namespace std ;
#include <time.h>
#include "Structures.H"
#include "Interface.H"

#import <OpenGL/OpenGL.h>
#import <OpenGL/gl.h>
#import <OpenGL/glu.h>
#import <OpenGL/glext.h>
#import <OpenGL/CGLRenderers.h>
#import <GLUT/glut.h>

void reshape(int w, int h) ;
void display(void) ;
void drawnode(Node *N) ;
void idle() ;
void mouse(int button, int state, int x, int y) ;
void motion(int x, int y) ;

Cloud *C ;
Node *drag ;
int size = 700 ;
double CLICK_STR = 5.0 ;

int main(int argc, char *argv[])
{

  // Initialize GL stuff
  glutInit(&argc, argv) ;
  glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA) ;
  glutInitWindowPosition(0,0) ;
  glutInitWindowSize(size,size) ;
  glutCreateWindow("RelationCloud") ;

  // Seed the random number generator
  srand(time(NULL)) ;

  // create and intitialize a cloud
  C = new Cloud ;
  CreateCloud(C) ; 

  glutDisplayFunc(display);
  glutReshapeFunc(reshape);
  glutIdleFunc(idle) ;
  glutMouseFunc(mouse) ; 
  glutMotionFunc(motion) ;

  glutMainLoop();
}

void idle()
{
  MoveNodes(C,0.03) ;
  display() ;
}

void display(void)
{
  glClearColor(1,1,1,0);
  glClear(GL_COLOR_BUFFER_BIT);

  Node *N = C->head ;
  while(N != NULL)
    {
      drawnode(N) ;
      N = N->next ;
    }

  glutSwapBuffers();
}

void drawnode(Node *N)
{
  double x = N->cx/size*2.0 ;
  double y = N->cy/size*2.0 ;
  double d = N->radius/size*2.0/2.0 ;
  double str = (N->str-20.0)/80.0*0.75 ;
 
  glBegin(GL_QUADS);
  {
    glColor3f(str,str,str);
    glVertex2f(x-d,y-d);

    glColor3f(str,str,str);
    glVertex2f(x+d,y-d);

    glColor3f(str,str,str);
    glVertex2f(x+d,y+d);

    glColor3f(str,str,str);
    glVertex2f(x-d,y+d);
  }
  glEnd();

}

void reshape(int w, int h)
{

}

void motion(int x, int y)
{
  if(drag != NULL)
    {
      drag->cx = x - size*0.5 ;
      drag->cy = size*0.5 - y ;
    }

}

void mouse(int button, int state, int x, int y) 
{
  if(button == 0)
    {	
      if(state == 0)
	{
	  drag = Find(C,x-0.5*size,0.5*size-y,20.0) ;
	  if(drag != NULL)
	    {
	      drag->imove = 0 ;
	      drag->str *= CLICK_STR ;
	    }
	  else
	    {
	      // then insert one
	      int rnd = rand() ;
	      double str = ((double)rnd)/((double)RAND_MAX)*80.0+20.0 ;
	      Node *N = new Node ;  
	      AddNode(C,N,str,20) ;
	    }
	}
      else
	{
	  if(drag != NULL)
	    {
	      drag->imove = 1 ;
	      drag->str /= CLICK_STR ;
	    }

	}
    }

  if(state == 0 && button == 2)
    {
      DeleteNode(C,Find(C,0)) ;
    }

}
