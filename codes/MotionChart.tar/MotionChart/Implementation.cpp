//
// RelationCloud Dynamics
//
// This code moves nodes around a central cloud using BubbleMesh ideas
// originally published as a mesh generation technique by Kenji
// Shimada.
//
// Nathan Collier, Dec 2009
//

#include <iostream>
#include <math.h>
using namespace std ;
#include "Structures.H"
#include "Interface.H"
#define SQ(a) ( (a)*(a) )

double DER_CUT = 1.0e-2 ;
double DAMPEN = 1.0 ;
double MASS = 1.0 ;

//-------------------------------------------------------------------//

void CreateCloud(Cloud *C) 
{
  // Create a new node that will be the center of the cloud
  Node *head = new Node ;
  C->head = head ;
 
  // Initial location of the cloud center
  C->head->cx = 0.0 ;
  C->head->cy = 0.0 ;
  C->head->next = NULL ;

  C->count = 0 ;
}

//-------------------------------------------------------------------//

void DeleteCloud(Cloud *C) 
{
  Node *curr ;
  curr = C->head ;

  // loop over all nodes and delete each one, including the head
  while(curr != NULL)
    {
      Node *del = curr ;
      curr = curr->next ;
      delete del ;
    }

  delete C ;
}

//-------------------------------------------------------------------//

void AddNode(Cloud *C,Node *N,double str,double radius) 
{
  // Add the node to the end of the list
  Node *curr = C->head ;
  while(curr->next != NULL)
    curr = curr->next ;
  curr->next = N ;
  N->next = NULL ;
  C->count++ ;
  N->imove = 1 ;

  // This radius measures the influence one node has on
  // another. Eventually this should be related to the size of text
  N->radius = radius ;
  // The higher the strength, the further it is pushed from the center
  N->str = str ;

  // Here we are trying to insert the node at the center, at a
  // slightly skewed position which is determined at random.
  int rnd = rand() ;
  double r = 6.28*((double)rnd)/((double)RAND_MAX) ;
  N->cx = 0.1*(N->str)*cos(r) ;
  N->cy = 0.1*(N->str)*sin(r) ;

  // Euler ODE Solver parameters
  N->cdx = 0.0 ; // initial dx/dt
  N->cdy = 0.0 ; // initial dy/dt
  N->c = DAMPEN ; // dampening coefficient
  N->m = MASS ; // mass coefficient
}

//-------------------------------------------------------------------//

void DeleteNode(Cloud *C,Node *N) 
{
  Node *prev, *curr ;
  prev = C->head ;
  curr = prev->next ;

  // loop over all nodes, when you find N delete it
  while(curr != NULL)
    {
      if(curr == N)
	{
	  prev->next = curr->next ;
	  delete curr ;
	  C->count-- ;
	  break ;
	}
    }

}

//-------------------------------------------------------------------//

void MoveNode(Cloud *C,Node *N,double dt) 
{

  // If a node is frozen, then don't move
  if(N->imove == 0) return ;

  // Euler's method for the x and y position
  N->cx += dt*N->cdx ;
  N->cy += dt*N->cdy ;
  
  // Get forcing information, start with the center
  double fx=0.0, fy=0.0 ;
  CentralForcing(C,N,fx,fy) ;

  // Now loop over all other nodes and skip the node we are moving
  Node *curr = C->head ;
  while(curr != NULL)
    {
      if(curr != N)
	{
	  NodetoNodeForcing(N,curr,fx,fy)  ;
	}
      curr = curr->next ;
    }

  // Euler's method for the x and y derivatives 
  N->cdx += (fx/(N->m) - (N->c)/(N->m)*(N->cdx))*dt ;
  N->cdy += (fy/(N->m) - (N->c)/(N->m)*(N->cdy))*dt ;

  // Enforce a cutoff for derivatives
  if(fabs(N->cdx) < DER_CUT) N->cdx = 0.0 ;
  if(fabs(N->cdy) < DER_CUT) N->cdy = 0.0 ;

}

//-------------------------------------------------------------------//

void MoveNodes(Cloud *C,double dt) 
{

  Node *curr = C->head->next ;
  while(curr != NULL)
    {
      MoveNode(C,curr,dt) ;
      curr = curr->next ;
    }

}

//-------------------------------------------------------------------//

void PlotCloud(Cloud *C,ostream &os) 
{
  Node *curr = C->head->next ;

  while(curr != NULL)
    {
      os << curr->cx << " " << curr->cy << endl ;
      curr = curr->next ;
    }
}

//-------------------------------------------------------------------//

void NodetoNodeForcing(Node *N1,Node *N2,double &fx, double &fy)
{
  // Each node is considered a bubble. The node-to-node forcing is
  // based on the interaction of the bubbles.
  double r0 = N1->radius + N2->radius ;
  double r = sqrt( SQ(N2->cx - N1->cx) +
		   SQ(N2->cy - N1->cy) ) ;

  double k0 = 1.0 ; // stiffness coefficient (-slope at r=r0)

  // coefficients of the cubic function (c=0)
  double a = 5.0*k0/14.0/r0/r0 ;
  double b = -k0*19.0/28.0/r0 ;
  double d = r0*k0*9.0/28.0 ;

  double f ;
  if(r > 1.5*r0) 
    f = 0.0 ;
  else
    f = -(a*r*r*r + b*r*r + d) ;

  // Split the force into components
  fx += f*(N2->cx - N1->cx)/r ;
  fy += f*(N2->cy - N1->cy)/r ;
}

//-------------------------------------------------------------------//

void CentralForcing(Cloud *C,Node *N,double &fx, double &fy)
{
  // The code here is the same, the difference is that each node will
  // resist the center node by its strength, not the radius of the
  // center node.
  Node *N2 = C->head ;
  double r0 = N->radius + N->str ;
  double r = sqrt( SQ(N2->cx - N->cx) +
		   SQ(N2->cy - N->cy) ) ;

  double k0 = 1.0 ;
  double a = 5.0*k0/14.0/r0/r0 ;
  double b = -k0*19.0/28.0/r0 ;
  double d = r0*k0*9.0/28.0 ;

  double f ;
  if(r > 1.5*r0) 
    f = 0.0 ;
  else
    f = -(a*r*r*r + b*r*r + d) ;

  fx += f*(N2->cx - N->cx)/r ;
  fy += f*(N2->cy - N->cy)/r ;

}

//-------------------------------------------------------------------//

extern int Size(Cloud *C)
{
  return C->count ;
}

//-------------------------------------------------------------------//

extern Node* Find(Cloud *C,int i) 
{
  Node *curr = C->head->next ;

  for(int j=0;j<i;j++)
    {
      curr = curr->next ;
    }
  return curr ;
}

//-------------------------------------------------------------------//

extern Node* Find(Cloud *C,double x, double y, double del) 
{
  Node *curr = C->head->next ;

  while(curr != NULL)
    {
      double xx = fabs(curr->cx - x) ;
      double yy = fabs(curr->cy - y) ;

      if(xx < del && yy < del) return curr ;
      curr = curr->next ;
    }

  return NULL ;
}

//-------------------------------------------------------------------//
