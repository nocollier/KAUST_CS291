#include "petsc.h"

int main(int argc, char *argv[]) {

  PetscErrorCode ierr;
  ierr = PetscInitialize(&argc,&argv,0,0);CHKERRQ(ierr);

  PetscInt N=5;

  // Setup
  Mat A;
  Vec b,x;
  MatCreateSeqDense(PETSC_COMM_SELF,N,N,PETSC_NULL,&A);
  VecCreateSeq(PETSC_COMM_SELF,N,&b);
  VecDuplicate(b,&x);

  // Matrix assembly
  PetscReal local[3],dx2 = (1./((PetscReal)N-1.)); dx2 *= dx2;
  local[0] =  1./dx2;
  local[1] = -2./dx2;
  local[2] =  1./dx2;
  PetscInt i,ind[3];
  for(i=1;i<N-1;i++){
    ind[0] = i-1; ind[1] = i; ind[2] = i+1;
    MatSetValues(A,1,&i,3,&ind[0],&local[0],INSERT_VALUES);
  }

  // Boundary conditions
  MatSetValue(A,0,0,1,INSERT_VALUES);
  MatSetValue(A,N-1,N-1,1,INSERT_VALUES);
  VecSetValue(b,N-1,1,INSERT_VALUES);

  // Finalize assembly
  MatAssemblyBegin(A,MAT_FINAL_ASSEMBLY);
  MatAssemblyEnd(A,MAT_FINAL_ASSEMBLY);
  VecAssemblyBegin(b);
  VecAssemblyEnd(b);

  // Setup the solution
  KSP ksp;
  KSPCreate(PETSC_COMM_SELF,&ksp);
  KSPSetOperators(ksp,A,A,SAME_PRECONDITIONER);
  KSPSetFromOptions(ksp);
  
  KSPSolve(ksp,b,x);

  VecView(x,PETSC_VIEWER_STDOUT_WORLD);

  MatDestroy(&A);
  PetscFinalize();
  return 0;
}
