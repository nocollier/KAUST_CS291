#include <strings.h>
#include <math.h>
#include <stdio.h>

#ifndef Forest_Has_Been_Defined
typedef struct forest
{
  int *Nodes ;
  int Size ;
} Forest;

#define Forest_Has_Been_Defined
#endif

