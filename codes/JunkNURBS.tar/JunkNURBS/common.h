      integer NSD, P, Q, R, MCP, NCP, OCP, NNODZ, NEL, 
     &             CLOSED_U_flag, CLOSED_V_flag, NGAUSS, NSHL,
     &             NEL_NZA, CLOSED_W_flag, NFACE, isolver

      real*8 DetJ, DetJb, ENRGY, ERROR

      common /comparint/ NSD, P, Q, R, MCP, NCP, OCP, NNODZ, NEL,
     &             CLOSED_U_flag, CLOSED_V_flag, NGAUSS, NSHL,
     &             NEL_NZA, CLOSED_W_flag, NFACE, isolver

      common /comparrel/ DetJ, DetJb, ENRGY, ERROR
       
