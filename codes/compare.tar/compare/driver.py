import numpy as np
import time
import sinc
import sinc_f2py

def sinc2(x):
    """
    sinc2(x)  = ( sin(pi x)/( pi x) )**2
    """
    y = np.zeros_like(x)
    for i in range(len(x)):
        y[i] = ( np.sin(np.pi*x[i]) / (np.pi*x[i]) )**2
    return y


x = np.random.rand(1000000)

tic = time.time()
y = sinc2(x)
toc = time.time()-tic
print "Looping in python: %.3e" % (toc)

tic = time.time()
y = np.sin(np.pi*x) / (np.pi*x)
y *= y
toc = time.time()-tic
print "Using numpy: %.3e" % (toc)

tic = time.time()
y = sinc.sinc2_method1(x)
toc = time.time()-tic
print "Using Cython method 1: %.3e" % (toc)

tic = time.time()
y = sinc.sinc2_method2(x)
toc = time.time()-tic
print "Using Cython method 2: %.3e" % (toc)

tic = time.time()
y = sinc_f2py.sinc2(x)
toc = time.time()-tic
print "Using f2py: %.3e" % (toc)

